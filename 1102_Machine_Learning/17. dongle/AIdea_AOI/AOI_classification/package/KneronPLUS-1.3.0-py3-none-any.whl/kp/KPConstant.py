# ******************************************************************************
#  Copyright (c) 2021. Kneron Inc. All rights reserved.                        *
# ******************************************************************************

from enum import Enum


class Const(Enum):
    """
    Kneron PLUS constant value.

    Attributes
    ----------
    MAX_CROP_BOX : int, default=4
        Maximum number of crop boxes.
    FD_MAX : int, default=10
        Maximum number of face detection bounding boxes.
    LAND_MARK_POINTS : int, default=5
        Number of land marks points.
    FR_FEAT_LENGTH : int, default=256
        The length of one feature map.
    YOLO_GOOD_BOX_MAX : int, default=100
        Maximum number of bounding boxes for Yolo models.
    APP_PADDING_BYTES : int, default=20
        Reserved padding bytes for C structure.
    """

    MAX_CROP_BOX = 4
    FD_MAX = 10
    LAND_MARK_POINTS = 5
    FR_FEAT_LENGTH = 256
    YOLO_GOOD_BOX_MAX = 100

    APP_PADDING_BYTES = 20
