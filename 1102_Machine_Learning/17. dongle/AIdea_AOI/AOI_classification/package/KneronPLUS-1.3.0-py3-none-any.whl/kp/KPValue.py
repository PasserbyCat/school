# ******************************************************************************
#  Copyright (c) 2021. Kneron Inc. All rights reserved.                        *
# ******************************************************************************

from .KPBaseClass.ValueBase import ValueRepresentBase, ValueBase
from .KPWrapperUtils import KPWrapperUtils as wrapper_utils
from .KPStructure import \
    DeviceDescriptorBuffer, \
    DeviceDescriptorListBuffer, \
    DeviceGroupBuffer, \
    SingleModelDescriptorBuffer, \
    ModelNefDescriptorBuffer, \
    FirmwareVersionBuffer, \
    SystemInfoBuffer, \
    InfConfigurationBuffer, \
    InfCropBoxBuffer, \
    GenericRawImageHeaderBuffer, \
    GenericRawResultNDArrayBuffer, \
    GenericRawResultHeaderBuffer, \
    GenericRawBypassPreProcImageHeaderBuffer, \
    GenericRawBypassPreProcResultHeaderBuffer, \
    InfFixedNodeOutputBuffer, \
    InfFloatNodeOutputBuffer, \
    BoundingBoxBuffer, \
    PointBuffer, \
    LandMarkBuffer, \
    ClassificationBuffer, \
    FaceRecognizeBuffer
from .KPEnum import *
from .KPConstant import Const
from typing import Union, List
import numpy as np
import ctypes


class DeviceDescriptor(ValueBase, ValueRepresentBase):
    """
    Information of one connected device from USB perspectives.

    Attributes
    ----------
    usb_port_id : int, default=0
        An unique ID representing for a Kneron device, can be used as input while connecting devices.
    vendor_id : int, default=0
        Supposed to be 0x3231.
    product_id : int, default=0
        USB PID (Product ID).
    link_speed : UsbSpeed, default=UsbSpeed.KP_USB_SPEED_UNKNOWN
        Enum for USB speed mode.
    kn_number : int, default=0
        KN number.
    is_connectable : bool, default=False
        Indicate if this device is connectable.
    usb_port_path : str, default=''
        "busNo-hub_portNo-device_portNo" (ex: "1-2-3", means bus 1 - (hub) port 2 - (device) port 3)
    firmware : str, default=''
        Firmware description.
    """

    def __init__(self,
                 usb_port_id: int = 0,
                 vendor_id: int = 0,
                 product_id: int = 0,
                 link_speed: UsbSpeed = UsbSpeed.KP_USB_SPEED_UNKNOWN,
                 kn_number: int = 0,
                 is_connectable: bool = False,
                 usb_port_path: str = '',
                 firmware: str = ''):
        """
        Information of one connected device from USB perspectives.

        Parameters
        ----------
        usb_port_id : int, default=0
            An unique ID representing for a Kneron device, can be used as input while connecting devices.
        vendor_id : int, default=0
            Supposed to be 0x3231.
        product_id : int, default=0
            USB PID (Product ID).
        link_speed : UsbSpeed, default=UsbSpeed.KP_USB_SPEED_UNKNOWN
            Enum for USB speed mode.
        kn_number : int, default=0
            KN number.
        is_connectable : bool, default=False
            Indicate if this device is connectable.
        usb_port_path : str, default=''
            "busNo-hub_portNo-device_portNo" (ex: "1-2-3", means bus 1 - (hub) port 2 - (device) port 3)
        firmware : str, default=''
            Firmware description.
        """
        ValueBase.__init__(self,
                           element_buffer_class=DeviceDescriptorBuffer,
                           usb_port_id=usb_port_id,
                           vendor_id=vendor_id,
                           product_id=product_id,
                           link_speed=link_speed,
                           kn_number=kn_number,
                           is_connectable=is_connectable,
                           usb_port_path=usb_port_path,
                           firmware=firmware)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def usb_port_id(self) -> int:
        """
        int: An unique ID representing for a Kneron device, can be used as input while connecting devices.
        """
        return self._element_buffer._port_id

    @property
    def vendor_id(self) -> int:
        """
        int: Supposed to be 0x3231.
        """
        return self._element_buffer._vendor_id

    @property
    def product_id(self) -> int:
        """
        int: USB PID (Product ID).
        """
        return self._element_buffer._product_id

    @property
    def link_speed(self) -> UsbSpeed:
        """
        UsbSpeed: Enum for USB speed mode.
        """
        return UsbSpeed(self._element_buffer._link_speed)

    @property
    def kn_number(self) -> int:
        """
        int: KN number.
        """
        return self._element_buffer._kn_number

    @property
    def is_connectable(self) -> bool:
        """
        bool: Indicate if this device is connectable.
        """
        return self._element_buffer._isConnectable

    @property
    def usb_port_path(self) -> str:
        """
        str: "busNo-hub_portNo-device_portNo" (ex: "1-2-3", means bus 1 - (hub) port 2 - (device) port 3)
        """
        return self._element_buffer._port_path.decode('utf-8')

    @property
    def firmware(self) -> str:
        """
        str: Firmware description.
        """
        return self._element_buffer._firmware.decode('utf-8')

    def get_member_variable_dict(self) -> dict:
        return {
            'usb_port_id': self.usb_port_id,
            'vendor_id': '0x{:X}'.format(self.vendor_id),
            'product_id': '0x{:X}'.format(self.product_id),
            'link_speed': str(self.link_speed),
            'kn_number': '0x{:X}'.format(self.kn_number),
            'is_connectable': self.is_connectable,
            'usb_port_path': self.usb_port_path,
            'firmware': self.firmware
        }


class DeviceDescriptorList(ValueBase, ValueRepresentBase):
    """
    Information of connected devices from USB perspectives.

    Attributes
    ----------
    device_descriptor_list : List[kp.DeviceDescriptor], default=[]
        DeviceDescriptor objects list, contain information of connected devices from USB perspectives.


    See Also
    --------
    kp.core.scan_devices : Scan all Kneron devices and report a list.
    kp.DeviceDescriptor
    """

    def __init__(self, device_descriptor_list: List[DeviceDescriptor] = []):
        """
        Information of connected devices from USB perspectives.

        Parameters
        ----------
        device_descriptor_list : List[kp.DeviceDescriptor], default=[]
            DeviceDescriptor objects list, contain information of connected devices from USB perspectives.
        """
        ValueBase.__init__(self,
                           element_buffer_class=DeviceDescriptorListBuffer,
                           device_descriptor_buffer_list=DeviceDescriptorList.__cast_list_to_buffer_list(
                               device_descriptor_list=device_descriptor_list))

    @staticmethod
    def __cast_list_to_buffer_list(device_descriptor_list: List[DeviceDescriptor]) -> List[DeviceDescriptorBuffer]:
        return [DeviceDescriptorBuffer(usb_port_id=device_descriptor.usb_port_id,
                                       vendor_id=device_descriptor.vendor_id,
                                       product_id=device_descriptor.product_id,
                                       link_speed=device_descriptor.link_speed,
                                       kn_number=device_descriptor.kn_number,
                                       is_connectable=device_descriptor.is_connectable,
                                       usb_port_path=device_descriptor.usb_port_path,
                                       firmware=device_descriptor.firmware) for device_descriptor in
                device_descriptor_list]

    def _cast_element_buffer(self) -> None:
        self._element_buffer = ctypes.pointer(self._element_buffer)

    def _get_element_buffer(self) -> Union[None, ctypes.POINTER]:
        return self._element_buffer

    @property
    def device_descriptor_number(self) -> int:
        """
        int: Number of connected devices.
        """
        return self._element_buffer.contents._num_dev

    @property
    def device_descriptor_list(self) -> List[DeviceDescriptor]:
        """
        List[kp.DeviceDescriptor]: DeviceDescriptor objects list, contain information of connected devices from USB
        perspectives.
        """
        device_descriptor_list = []

        if 0 < self._element_buffer.contents._num_dev:
            if self._is_allocate_from_c:
                _address = ctypes.addressof(self._element_buffer.contents._device)
                _device_descriptor_buffer_list = list(
                    (DeviceDescriptorBuffer * self._element_buffer.contents._num_dev).from_address(_address))[
                                                 :self._element_buffer.contents._num_dev]
            else:
                _device_descriptor_buffer_list = self._element_buffer.contents._device[
                                                 :self._element_buffer.contents._num_dev]

            device_descriptor_list = [DeviceDescriptor(
                usb_port_id=device_descriptor_buffer._port_id,
                vendor_id=device_descriptor_buffer._vendor_id,
                product_id=device_descriptor_buffer._product_id,
                link_speed=UsbSpeed(device_descriptor_buffer._link_speed),
                kn_number=device_descriptor_buffer._kn_number,
                is_connectable=device_descriptor_buffer._isConnectable,
                usb_port_path=device_descriptor_buffer._port_path.decode('utf-8'),
                firmware=device_descriptor_buffer._firmware.decode('utf-8'),
            ) for device_descriptor_buffer in _device_descriptor_buffer_list]

        return device_descriptor_list

    def get_member_variable_dict(self) -> dict:
        member_variable_dict = {}

        for idx, device_descriptor in enumerate(self.device_descriptor_list):
            member_variable_dict[idx] = device_descriptor.get_member_variable_dict()

        return member_variable_dict


class DeviceGroup(ValueBase, ValueRepresentBase):
    """
    A handle represent connected Kneron device.

    Attributes
    ----------
    address : int
        Memory address of connected Kneron device handler.
    """

    def __init__(self, address: int):
        """
        A handle represent connected Kneron device.

        Parameters
        ----------
        address : int
            Memory address of connected Kneron device handler.
        """
        ValueBase.__init__(self,
                           element_buffer_class=DeviceGroupBuffer,
                           address=address)

    def __del__(self):
        if self._is_allocate_from_c:
            status = wrapper_utils.disconnect_devices_by_address(self._element_buffer._address)
            self._is_allocate_from_c = False

            if ApiReturnCode.KP_SUCCESS != ApiReturnCode(status):
                raise MemoryError(
                    'DeviceGroup auto disconnect fail. Error Code - {}'.format(str(ApiReturnCode(status))))

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def address(self) -> int:
        """
        int: Memory address of connected Kneron device handler.
        """
        return self._element_buffer._address

    def get_member_variable_dict(self) -> dict:
        return {'device_group_address ': '0x{:X}'.format(self.address)}


class SingleModelDescriptor(ValueBase, ValueRepresentBase):
    """
    A basic descriptor for a model.

    Attributes
    ----------
    id : int, default=0
        Model ID.
    max_raw_out_size : int, default=0
        Needed raw output buffer size for this model.
    width : int, default=0
        The input width of this model.
    height : int, default=0
        The input height of this model.
    channel : int, default=0
        The input channel of this model.
    img_format : kp.ImageFormat, default=kp.ImageFormat.KP_IMAGE_FORMAT_RGBA8888
        The input image format of this model.
    """

    def __init__(self,
                 id: int = 0,
                 max_raw_out_size: int = 0,
                 width: int = 0,
                 height: int = 0,
                 channel: int = 0,
                 img_format: ImageFormat = ImageFormat.KP_IMAGE_FORMAT_RGBA8888):
        """
        A basic descriptor for a model.

        Parameters
        ----------
        id : int, default=0
            Model ID.
        max_raw_out_size : int, default=0
            Needed raw output buffer size for this model.
        width : int, default=0
            The input width of this model.
        height : int, default=0
            The input height of this model.
        channel : int, default=0
            The input channel of this model.
        img_format : kp.ImageFormat, default=kp.ImageFormat.KP_IMAGE_FORMAT_RGBA8888
            The input image format of this model.
        """
        ValueBase.__init__(self,
                           element_buffer_class=SingleModelDescriptorBuffer,
                           id=id,
                           max_raw_out_size=max_raw_out_size,
                           width=width,
                           height=height,
                           channel=channel,
                           img_format=img_format)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def id(self) -> int:
        """
        int: Model ID.
        """
        return self._element_buffer._id

    @property
    def max_raw_out_size(self) -> int:
        """
        int: Needed raw output buffer size for this model.
        """
        return self._element_buffer._max_raw_out_size

    @property
    def width(self) -> int:
        """
        int: The input width of this model.
        """
        return self._element_buffer._width

    @property
    def height(self) -> int:
        """
        int: input height of this model.
        """
        return self._element_buffer._height

    @property
    def channel(self) -> int:
        """
        int: The input channel of this model.
        """
        return self._element_buffer._channel

    @property
    def img_format(self) -> ImageFormat:
        """
        kp.ImageFormat: The input image format of this model.
        """
        return ImageFormat(self._element_buffer._img_format)

    def get_member_variable_dict(self) -> dict:
        return {
            'id': self.id,
            'max_raw_out_size': self.max_raw_out_size,
            'width': self.width,
            'height': self.height,
            'channel': self.channel,
            'img_format': str(self.img_format)
        }


class ModelNefDescriptor(ValueBase, ValueRepresentBase):
    """
    A basic descriptor for a NEF.

    Attributes
    ----------
    crc : int, default=0
        The CRC of all models.
    num_models : int, default=0
        The number of models contains in NEF.
    models : List[kp.SingleModelDescriptor], default=[]
        SingleModelDescriptor objects list, contain information of uploaded NEF information.
    """

    def __init__(self,
                 crc: int = 0,
                 num_models: int = 0,
                 models: List[SingleModelDescriptor] = []):
        """
        A basic descriptor for a NEF.

        Parameters
        ----------
        crc : int, default=0
            The CRC of all models.
        num_models : int, default=0
            The number of models contains in NEF.
        models : List[kp.SingleModelDescriptor], default=[]
            SingleModelDescriptor objects list, contain information of uploaded NEF information.
        """
        ValueBase.__init__(self,
                           element_buffer_class=ModelNefDescriptorBuffer,
                           crc=crc,
                           num_models=num_models,
                           models=ModelNefDescriptor.__cast_list_to_buffer_list(models=models))

    @staticmethod
    def __cast_list_to_buffer_list(models: List[SingleModelDescriptor]) -> List[SingleModelDescriptorBuffer]:
        return [SingleModelDescriptorBuffer(id=single_model_descriptor.id,
                                            max_raw_out_size=single_model_descriptor.max_raw_out_size,
                                            width=single_model_descriptor.width,
                                            height=single_model_descriptor.height,
                                            channel=single_model_descriptor.channel,
                                            img_format=single_model_descriptor.img_format
                                            ) for single_model_descriptor in models]

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def crc(self) -> int:
        """
        int: The CRC of all models.
        """
        return self._element_buffer._crc

    @property
    def num_models(self) -> int:
        """
        int: The number of models contains in NEF.
        """
        return self._element_buffer._num_models

    @property
    def models(self) -> List[SingleModelDescriptor]:
        """
        List[kp.SingleModelDescriptor]: SingleModelDescriptor objects list, contain information of uploaded NEF information.
        """
        single_model_descriptor_buffer_list = list(self._element_buffer._models)[:self._element_buffer._num_models]
        models = []
        if 0 < self._element_buffer._num_models:
            models = [SingleModelDescriptor(
                id=single_model_descriptor_buffer._id,
                max_raw_out_size=single_model_descriptor_buffer._max_raw_out_size,
                width=single_model_descriptor_buffer._width,
                height=single_model_descriptor_buffer._height,
                channel=single_model_descriptor_buffer._channel,
                img_format=ImageFormat(single_model_descriptor_buffer._img_format)
            ) for single_model_descriptor_buffer in single_model_descriptor_buffer_list]
        return models

    def get_member_variable_dict(self) -> dict:
        member_variable_dict = {
            'crc': '0x{:X}'.format(self.crc),
            'num_models': self.num_models,
            'models': {}
        }

        for idx, single_model_descriptor in enumerate(self.models):
            member_variable_dict['models'][idx] = single_model_descriptor.get_member_variable_dict()

        return member_variable_dict


class FirmwareVersion(ValueBase, ValueRepresentBase):
    """
    Information of firmware version.

    Attributes
    ----------
    reserved : int, default=0
        Reserved version number for backward compatibility.
    major : int, default=0
    minor : int, default=0
    update : int, default=0
    build : int, default=0
    """

    def __init__(self,
                 reserved: int = 0,
                 major: int = 0,
                 minor: int = 0,
                 update: int = 0,
                 build: int = 0):
        """
        Information of firmware version.

        Parameters
        ----------
        reserved : int, default=0
            Reserved version number for backward compatibility.
        major : int, default=0
        minor : int, default=0
        update : int, default=0
        build : int, default=0
        """
        ValueBase.__init__(self,
                           element_buffer_class=FirmwareVersionBuffer,
                           reserved=reserved,
                           major=major,
                           minor=minor,
                           update=update,
                           build=build)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def reserved(self) -> int:
        """
        int: Reserved version number for backward compatibility.
        """
        return self._element_buffer._reserved

    @property
    def major(self) -> int:
        return self._element_buffer._major

    @property
    def minor(self) -> int:
        return self._element_buffer._minor

    @property
    def update(self) -> int:
        return self._element_buffer._update

    @property
    def build(self) -> int:
        return self._element_buffer._build

    def get_member_variable_dict(self) -> dict:
        if self.reserved == 0:
            return {
                'firmware_version': '{}.{}.{}-build.{}'.format(
                    self.major,
                    self.minor,
                    self.update,
                    self.build
                )
            }
        else:
            return {
                'firmware_version': '{}.{}.{}.{}-build.{}'.format(
                    self.reserved,
                    self.major,
                    self.minor,
                    self.update,
                    self.build
                )
            }


class SystemInfo(ValueBase, ValueRepresentBase):
    """
    System Information of Kneron device.

    Attributes
    ----------
    kn_number : int, default=0
        Unique Kneron device ID.
    firmware_version : kp.FirmwareVersion, default=kp.FirmwareVersion()
        Firmware version of Kneron device.
    """

    def __init__(self,
                 kn_number: int = 0,
                 firmware_version: FirmwareVersion = FirmwareVersion()):
        """
        System Information of Kneron device.

        Parameters
        ----------
        kn_number : int, default=0
            Unique Kneron device ID.
        firmware_version : kp.FirmwareVersion, default=kp.FirmwareVersion()
            Firmware version of Kneron device.
        """
        ValueBase.__init__(self,
                           element_buffer_class=SystemInfoBuffer,
                           kn_number=kn_number,
                           firmware_version=firmware_version._get_element_buffer())

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def kn_number(self):
        """
        int: Unique Kneron device ID.
        """
        return self._element_buffer._kn_number

    @property
    def firmware_version(self):
        """
        kp.FirmwareVersion: Firmware version of Kneron device.
        """
        return FirmwareVersion(
            reserved=self._element_buffer._firmware_version._reserved,
            major=self._element_buffer._firmware_version._major,
            minor=self._element_buffer._firmware_version._minor,
            update=self._element_buffer._firmware_version._update,
            build=self._element_buffer._firmware_version._build
        )

    def get_member_variable_dict(self) -> dict:
        return {
            'kn_number': '0x{:X}'.format(self.kn_number),
            'firmware_version': self.firmware_version.get_member_variable_dict()['firmware_version'],
        }


class InferenceConfiguration(ValueBase, ValueRepresentBase):
    """
    Inference configurations.

    Attributes
    ----------
    enable_frame_drop : bool, default=False
        Enable this to keep inference non-blocking by dropping oldest and unprocessed frames.
    """

    def __init__(self,
                 enable_frame_drop: bool = False):
        """
        Inference configurations.

        Parameters
        ----------
        enable_frame_drop : bool, default=False
            Enable this to keep inference non-blocking by dropping oldest and unprocessed frames.
        """
        ValueBase.__init__(self,
                           element_buffer_class=InfConfigurationBuffer,
                           enable_frame_drop=enable_frame_drop)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def enable_frame_drop(self) -> bool:
        """
        bool: Enable this to keep inference non-blocking by dropping oldest and unprocessed frames.
        """
        return self._element_buffer._enable_frame_drop

    @enable_frame_drop.setter
    def enable_frame_drop(self, value: bool):
        self._element_buffer._enable_frame_drop = value

    def get_member_variable_dict(self) -> dict:
        return {
            'enable_frame_drop': self.enable_frame_drop
        }


class InferenceCropBox(ValueBase, ValueRepresentBase):
    """
    Class for an image crop region.

    Attributes
    ----------
    crop_box_index : int, default=0
        Index number of crop box.
    x : int, default=0
        X coordinate of crop box top-left corner.
    y : int, default=0
        Y coordinate of crop box top-left corner.
    width : int, default=0
        Width coordinate of crop box.
    height : int, default=0
        Height coordinate of crop box.
    """

    def __init__(self,
                 crop_box_index: int = 0,
                 x: int = 0,
                 y: int = 0,
                 width: int = 0,
                 height: int = 0):
        """
        Class for an image crop region.

        Parameters
        ----------
        crop_box_index : int, default=0
            Index number of crop box.
        x : int, default=0
            X coordinate of crop box top-left corner.
        y : int, default=0
            Y coordinate of crop box top-left corner.
        width : int, default=0
            Width coordinate of crop box.
        height : int, default=0
            Height coordinate of crop box.
        """
        ValueBase.__init__(self,
                           element_buffer_class=InfCropBoxBuffer,
                           crop_box_index=crop_box_index,
                           x=x,
                           y=y,
                           width=width,
                           height=height)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def crop_box_index(self) -> int:
        """
        int: Index number of crop box.
        """
        return self._element_buffer._crop_number

    @crop_box_index.setter
    def crop_box_index(self, value: int):
        self._element_buffer._crop_number = value

    @property
    def x(self) -> int:
        """
        int: X coordinate of crop box top-left corner.
        """
        return self._element_buffer._x1

    @x.setter
    def x(self, value: int):
        self._element_buffer._x1 = value

    @property
    def y(self) -> int:
        """
        int: Y coordinate of crop box top-left corner.
        """
        return self._element_buffer._y1

    @y.setter
    def y(self, value: int):
        self._element_buffer._y1 = value

    @property
    def width(self) -> int:
        """
        int: Width coordinate of crop box.
        """
        return self._element_buffer._width

    @width.setter
    def width(self, value: int):
        self._element_buffer._width = value

    @property
    def height(self) -> int:
        """
        int: Height coordinate of crop box.
        """
        return self._element_buffer._height

    @height.setter
    def height(self, value: int):
        self._element_buffer._height = value

    def get_member_variable_dict(self) -> dict:
        return {
            'crop_box_index': self.crop_box_index,
            'x': self.x,
            'y': self.y,
            'width': self.width,
            'height': self.height
        }


class GenericRawImageHeader(ValueBase, ValueRepresentBase):
    """
    Inference descriptor for images.

    Attributes
    ----------
    model_id : int, default=0
        Target inference model ID.
    resize_mode : kp.ResizeMode, default=kp.ResizeMode.KP_RESIZE_ENABLE
        Preprocess resize mode, refer to ResizeMode.
    padding_mode : kp.PaddingMode, default=kp.PaddingMode.KP_PADDING_CORNER
        Preprocess padding mode, refer to PaddingMode.
    normalize_mode : kp.NormalizeMode, default=kp.NormalizeMode.KP_NORMALIZE_KNERON
        Inference normalization, refer to NormalizeMode.
    inference_number : int, default=0
        Inference sequence number.
    inference_crop_box_list : List[kp.InferenceCropBox], default=[]
        Box information to crop.
    width : int, default=0
        Inference image width.
    height : int, default=0
        Inference image height.
    image_format : kp.ImageFormat, default=kp.ImageFormat.KP_IMAGE_FORMAT_RGB565
        Inference image format, refer to ImageFormat.
    """

    def __init__(self,
                 model_id: int = 0,
                 resize_mode: ResizeMode = ResizeMode.KP_RESIZE_ENABLE,
                 padding_mode: PaddingMode = PaddingMode.KP_PADDING_CORNER,
                 normalize_mode: NormalizeMode = NormalizeMode.KP_NORMALIZE_KNERON,
                 inference_number: int = 0,
                 inference_crop_box_list: List[InferenceCropBox] = [],
                 width: int = 0,
                 height: int = 0,
                 image_format: ImageFormat = ImageFormat.KP_IMAGE_FORMAT_RGB565):
        """
        Inference descriptor for images.

        Parameters
        ----------
        model_id : int, default=0
            Target inference model ID.
        resize_mode : kp.ResizeMode, default=kp.ResizeMode.KP_RESIZE_ENABLE
            Preprocess resize mode, refer to ResizeMode.
        padding_mode : kp.PaddingMode, default=kp.PaddingMode.KP_PADDING_CORNER
            Preprocess padding mode, refer to PaddingMode.
        normalize_mode : kp.NormalizeMode, default=kp.NormalizeMode.KP_NORMALIZE_KNERON
            Inference normalization, refer to NormalizeMode.
        inference_number : int, default=0
            Inference sequence number.
        inference_crop_box_list : List[kp.InferenceCropBox], default=[]
            Box information to crop.
        width : int, default=0
            Inference image width.
        height : int, default=0
            Inference image height.
        image_format : kp.ImageFormat, default=kp.ImageFormat.KP_IMAGE_FORMAT_RGB565
            Inference image format, refer to ImageFormat.
        """
        ValueBase.__init__(self,
                           element_buffer_class=GenericRawImageHeaderBuffer,
                           width=width,
                           height=height,
                           resize_mode=resize_mode,
                           padding_mode=padding_mode,
                           image_format=image_format,
                           normalize_mode=normalize_mode,
                           inference_number=inference_number,
                           model_id=model_id,
                           inference_crop_box_buffer_list=GenericRawImageHeader.__cast_list_to_buffer_list(
                               inference_crop_box_list=inference_crop_box_list))

    @staticmethod
    def __cast_list_to_buffer_list(inference_crop_box_list: List[InferenceCropBox]) -> List[InfCropBoxBuffer]:
        return [InfCropBoxBuffer(crop_box_index=inference_crop_box.crop_box_index,
                                 x=inference_crop_box.x,
                                 y=inference_crop_box.y,
                                 width=inference_crop_box.width,
                                 height=inference_crop_box.height) for inference_crop_box in inference_crop_box_list]

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def width(self) -> int:
        """
        int: Inference image width.
        """
        return self._element_buffer._width

    @width.setter
    def width(self, value: int):
        self._element_buffer._width = value

    @property
    def height(self) -> int:
        """
        int: Inference image height.
        """
        return self._element_buffer._height

    @height.setter
    def height(self, value: int):
        self._element_buffer._height = value

    @property
    def resize_mode(self) -> ResizeMode:
        """
        kp.ResizeMode: Preprocess resize mode, refer to ResizeMode.
        """
        return ResizeMode(self._element_buffer._resize_mode)

    @resize_mode.setter
    def resize_mode(self, value: ResizeMode):
        self._element_buffer._resize_mode = value.value

    @property
    def padding_mode(self) -> PaddingMode:
        """
        kp.PaddingMode: Preprocess padding mode, none or auto refer to PaddingMode.
        """
        return PaddingMode(self._element_buffer._padding_mode)

    @padding_mode.setter
    def padding_mode(self, value: PaddingMode):
        self._element_buffer._padding_mode = value.value

    @property
    def image_format(self) -> ImageFormat:
        """
        kp.ImageFormat: Inference image format, refer to ImageFormat.
        """
        return ImageFormat(self._element_buffer._image_format)

    @image_format.setter
    def image_format(self, value: ImageFormat):
        self._element_buffer._image_format = value.value

    @property
    def normalize_mode(self) -> NormalizeMode:
        """
        kp.NormalizeMode: Inference normalization, refer to NormalizeMode.
        """
        return NormalizeMode(self._element_buffer._normalize_mode)

    @normalize_mode.setter
    def normalize_mode(self, value: NormalizeMode):
        self._element_buffer._normalize_mode = value.value

    @property
    def inference_number(self) -> int:
        """
        int: Inference sequence number.
        """
        return self._element_buffer._inference_number

    @inference_number.setter
    def inference_number(self, value: int):
        self._element_buffer._inference_number = value

    @property
    def model_id(self) -> int:
        """
        int: Target inference model ID.
        """
        return self._element_buffer._model_id

    @model_id.setter
    def model_id(self, value):
        self._element_buffer._model_id = value

    @property
    def crop_count(self) -> int:
        """
        int: Number of crop box.
        """
        return self._element_buffer._crop_count

    @property
    def inference_crop_box_list(self) -> List[InferenceCropBox]:
        """
        List[kp.InferenceCropBox]: Box information to crop.
        """
        inference_crop_box_buffer_list = list(self._element_buffer._inf_crop)[:self.crop_count]

        inference_crop_box_list = [InferenceCropBox(
            crop_box_index=inference_crop_box_buffer._crop_number,
            x=inference_crop_box_buffer._x1,
            y=inference_crop_box_buffer._y1,
            width=inference_crop_box_buffer._width,
            height=inference_crop_box_buffer._height
        ) for inference_crop_box_buffer in inference_crop_box_buffer_list]

        return inference_crop_box_list

    # todo. not allow user setting it -> private it.
    @inference_crop_box_list.setter
    def inference_crop_box_list(self, value: List[InferenceCropBox] = []):
        self._element_buffer._crop_count = len(value)
        self._element_buffer._inf_crop = (InfCropBoxBuffer * Const.MAX_CROP_BOX.value)(*[
            InfCropBoxBuffer(crop_box_index=inference_crop_box.crop_box_index,
                             x=inference_crop_box.x,
                             y=inference_crop_box.y,
                             width=inference_crop_box.width,
                             height=inference_crop_box.height) for inference_crop_box in value])

    def get_member_variable_dict(self) -> dict:
        member_variable_dict = {
            'image': {
                'width': self.width,
                'height': self.height,
                'image_format': str(self.image_format)
            },
            'inference_configuration': {
                'resize_mode': str(self.resize_mode),
                'padding_mode': str(self.padding_mode),
                'normalize_mode': str(self.normalize_mode),
                'inference_number': self.inference_number,
                'model_id': self.model_id,
                'crop_count': self.crop_count,
                'inference_crop_box_list': {},
            }
        }

        for idx, inference_crop_box_element in enumerate(self.inference_crop_box_list):
            member_variable_dict['inference_configuration']['inference_crop_box_list'][
                idx] = inference_crop_box_element.get_member_variable_dict()

        return member_variable_dict


class GenericRawResultHeader(ValueBase, ValueRepresentBase):
    """
    Inference raw output descriptor.

    Attributes
    ----------
    inference_number : int, default=0
        Inference sequence number.
    crop_number : int, default=0
        Crop box sequence number.
    num_output_node : int, default=0
        Total number of output nodes.
    """

    def __init__(self,
                 inference_number: int = 0,
                 crop_number: int = 0,
                 num_output_node: int = 0):
        """
        Inference raw output descriptor.

        Parameters
        ----------
        inference_number : int, default=0
            Inference sequence number.
        crop_number : int, default=0
            Crop box sequence number.
        num_output_node : int, default=0
            Total number of output nodes.
        """
        ValueBase.__init__(self,
                           element_buffer_class=GenericRawResultHeaderBuffer,
                           inference_number=inference_number,
                           crop_number=crop_number,
                           num_output_node=num_output_node)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def inference_number(self) -> int:
        """
        int: Inference sequence number.
        """
        return self._element_buffer._inference_number

    @property
    def crop_number(self) -> int:
        """
        int: Crop box sequence number.
        """
        return self._element_buffer._crop_number

    @property
    def num_output_node(self) -> int:
        """
        int: Total number of output nodes.
        """
        return self._element_buffer._num_output_node

    def get_member_variable_dict(self) -> dict:
        return {
            'inference_number': self.inference_number,
            'crop_number': self.crop_number,
            'num_output_node': self.num_output_node
        }


class GenericRawResultNDArray(ValueBase, ValueRepresentBase):
    """
    Inference raw result buffer.

    Attributes
    ----------
    buffer_size : int
        Size of generic inference raw result buffer.
    """

    def __init__(self, buffer_size: int):
        """
        Generic inference raw result buffer.

        Parameters
        ----------
        buffer_size : int
            Size of generic inference raw result buffer.
        """
        ValueBase.__init__(self,
                           element_buffer_class=GenericRawResultNDArrayBuffer,
                           buffer_size=buffer_size)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def buffer_size(self) -> int:
        """
        int: Size of generic inference raw result buffer.
        """
        return self._element_buffer._buffer_size

    def get_member_variable_dict(self) -> dict:
        return {
            'buffer_size': self.buffer_size
        }


class GenericRawResult(ValueRepresentBase):
    """
    Generic inference raw result.

    Attributes
    ----------
    header : kp.GenericRawResultHeader
        Inference raw output descriptor.
    raw_result : kp.GenericRawResultNDArray
        Inference raw result buffer.
    """

    def __init__(self, buffer_size: int):
        """
        Generic inference raw result.

        Parameters
        ----------
        buffer_size : int
            Size of generic inference raw result buffer.
        """
        self.__header = GenericRawResultHeader()
        self.__raw_result = GenericRawResultNDArray(buffer_size=buffer_size)

    @property
    def header(self) -> GenericRawResultHeader:
        """
        kp.GenericRawResultHeader: Inference raw output descriptor.
        """
        return self.__header

    @property
    def raw_result(self) -> GenericRawResultNDArray:
        """
        kp.GenericRawResultNDArray: Inference raw result buffer.
        """
        return self.__raw_result

    def get_member_variable_dict(self) -> dict:
        return {
            'header': self.header.get_member_variable_dict(),
            'raw_result': self.raw_result.get_member_variable_dict()
        }


class GenericRawBypassPreProcImageHeader(ValueBase, ValueRepresentBase):
    """
    Inference descriptor for images bypass pre-processing.

    Attributes
    ----------
    model_id : int, default=0
        Target inference model ID.
    inference_number : int, default=0
        Inference sequence number.
    image_buffer_size : int, default=0
        Inference image buffer size.
    """

    def __init__(self,
                 model_id: int = 0,
                 inference_number: int = 0,
                 image_buffer_size: int = 0):
        """
        Inference descriptor for images bypass pre-processing.

        Attributes
        ----------
        model_id : int, default=0
            Target inference model ID.
        inference_number : int, default=0
            Inference sequence number.
        image_buffer_size : int, default=0
            Inference image buffer size.
        """
        ValueBase.__init__(self,
                           element_buffer_class=GenericRawBypassPreProcImageHeaderBuffer,
                           model_id=model_id,
                           inference_number=inference_number,
                           image_buffer_size=image_buffer_size)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def inference_number(self) -> int:
        """
        int: Inference sequence number.
        """
        return self._element_buffer._inference_number

    @inference_number.setter
    def inference_number(self, value: int):
        self._element_buffer._inference_number = value

    @property
    def model_id(self) -> int:
        """
        int: Target inference model ID.
        """
        return self._element_buffer._model_id

    @model_id.setter
    def model_id(self, value):
        self._element_buffer._model_id = value

    @property
    def image_buffer_size(self) -> int:
        """
        int: Inference image buffer size.
        """
        return self._element_buffer._image_buffer_size

    @image_buffer_size.setter
    def image_buffer_size(self, value):
        self._element_buffer._image_buffer_size = value

    def get_member_variable_dict(self) -> dict:
        return {
            'inference_number': self.inference_number,
            'model_id': self.model_id,
            'image_buffer_size': self.image_buffer_size
        }


class GenericRawBypassPreProcResultHeader(ValueBase, ValueRepresentBase):
    """
    Inference raw output descriptor for bypass pre-processing.

    Attributes
    ----------
    inference_number : int, default=0
        Inference sequence number.
    crop_number : int, default=0
        Crop box sequence number.
    num_output_node : int, default=0
        Total number of output nodes.
    """

    def __init__(self,
                 inference_number: int = 0,
                 crop_number: int = 0,
                 num_output_node: int = 0):
        """
        Inference raw output descriptor for bypass pre-processing.

        Parameters
        ----------
        inference_number : int, default=0
            Inference sequence number.
        crop_number : int, default=0
            Crop box sequence number.
        num_output_node : int, default=0
            Total number of output nodes.
        """
        ValueBase.__init__(self,
                           element_buffer_class=GenericRawBypassPreProcResultHeaderBuffer,
                           inference_number=inference_number,
                           crop_number=crop_number,
                           num_output_node=num_output_node)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def inference_number(self) -> int:
        """
        int: Inference sequence number.
        """
        return self._element_buffer._inference_number

    @property
    def crop_number(self) -> int:
        """
        int: Crop box sequence number.
        """
        return self._element_buffer._crop_number

    @property
    def num_output_node(self) -> int:
        """
        int: Total number of output nodes.
        """
        return self._element_buffer._num_output_node

    def get_member_variable_dict(self) -> dict:
        return {
            'inference_number': self.inference_number,
            'crop_number': self.crop_number,
            'num_output_node': self.num_output_node
        }


class GenericRawBypassPreProcResult(ValueRepresentBase):
    """
    Generic inference raw result for bypass pre-processing.

    Attributes
    ----------
    header : kp.GenericRawBypassPreProcResultHeader
        Inference raw output descriptor for bypass pre-processing.
    raw_result : kp.GenericRawResultNDArray
        Inference raw result buffer.
    """

    def __init__(self, buffer_size: int):
        """
        Generic inference raw result for bypass pre-processing.

        Parameters
        ----------
        buffer_size : int
            Size of generic inference raw result buffer.
        """
        self.__header = GenericRawBypassPreProcResultHeader()
        self.__raw_result = GenericRawResultNDArray(buffer_size=buffer_size)

    @property
    def header(self) -> GenericRawBypassPreProcResultHeader:
        """
        kp.GenericRawBypassPreProcResultHeader: Inference raw output descriptor for bypass pre-processing.
        """
        return self.__header

    @property
    def raw_result(self) -> GenericRawResultNDArray:
        """
        kp.GenericRawResultNDArray: Inference raw result buffer.
        """
        return self.__raw_result

    def get_member_variable_dict(self) -> dict:
        return {
            'header': self.header.get_member_variable_dict(),
            'raw_result': self.raw_result.get_member_variable_dict()
        }


class InferenceFloatNodeOutput(ValueBase, ValueRepresentBase):
    """
    Generic inference node output in floating-point format.

    Attributes
    ----------
    width : int, default=0
        Width of output node.
    height : int, default=0
        Height of output node.
    channel : int, default=0
        Channel of output node.
    num_data : int, default=0
        Total number of floating-point values.
    data : np.ndarray, default=np.array([])
        N-dimensional numpy.ndarray of feature map. (Channel ordering: KL520 - H,C,W; KL720 - C,H,W)
    channels_ordering : kp.ChannelOrdering, default=kp.ChannelOrdering.KP_CHANNEL_ORDERING_CHW
        Specify channel ordering of feature map. (Options: KP_CHANNEL_ORDERING_HCW, KP_CHANNEL_ORDERING_CHW)
    """

    def __init__(self,
                 width: int = 0,
                 height: int = 0,
                 channel: int = 0,
                 num_data: int = 0,
                 data: np.ndarray = np.array([]),
                 channels_ordering: ChannelOrdering = ChannelOrdering.KP_CHANNEL_ORDERING_CHW):
        """
        Generic inference node output in floating-point format.

        Parameters
        ----------
        width : int, default=0
            Width of output node.
        height : int, default=0
            Height of output node.
        channel : int, default=0
            Channel of output node.
        num_data : int, default=0
            Total number of floating-point values.
        data : np.ndarray, default=np.array([])
            N-dimensional numpy.ndarray of feature map. (Channel ordering: KL520 - H,C,W; KL720 - C,H,W)
        channels_ordering : kp.ChannelOrdering, default=kp.ChannelOrdering.KP_CHANNEL_ORDERING_CHW
            Specify channel ordering of feature map. (Options: KP_CHANNEL_ORDERING_HCW, KP_CHANNEL_ORDERING_CHW)
        """
        ValueBase.__init__(self,
                           element_buffer_class=InfFloatNodeOutputBuffer,
                           width=width,
                           height=height,
                           channel=channel,
                           num_data=num_data,
                           data=data)

        self.__channels_ordering = channels_ordering

    def __del__(self):
        if self._is_allocate_from_c:
            wrapper_utils.c_free(pointer=self._element_buffer.contents)
            self._is_allocate_from_c = False

    def _cast_element_buffer(self) -> None:
        self._element_buffer = ctypes.pointer(self._element_buffer)

    def _get_element_buffer(self) -> Union[None, ctypes.POINTER]:
        return self._element_buffer

    @property
    def width(self) -> int:
        """
        int: Width of output node.
        """
        return self._element_buffer.contents._width

    @property
    def height(self) -> int:
        """
        int: Height of output node.
        """
        return self._element_buffer.contents._height

    @property
    def channel(self) -> int:
        """
        int: Channel of output node.
        """
        return self._element_buffer.contents._channel

    @property
    def num_data(self) -> int:
        """
        int: Total number of floating-point values.
        """
        return self._element_buffer.contents._num_data

    @property
    def ndarray(self) -> np.ndarray:
        """
        numpy.ndarray: N-dimensional numpy.ndarray of feature map.
        """
        if self._is_allocate_from_c:
            address = ctypes.addressof(self._element_buffer.contents._data)
            buffer_as_ctypes_array = (ctypes.c_float * self._element_buffer.contents._num_data).from_address(address)
        else:
            buffer_as_ctypes_array = self._element_buffer.contents._data[:self._element_buffer.contents._num_data]

        ret_ndarray = np.ctypeslib.as_array(buffer_as_ctypes_array)

        if self.channels_ordering == ChannelOrdering.KP_CHANNEL_ORDERING_CHW:
            ret_ndarray = ret_ndarray.reshape((self.channel, self.height, self.width))
        elif self.channels_ordering == ChannelOrdering.KP_CHANNEL_ORDERING_HCW:
            ret_ndarray = ret_ndarray.reshape((self.height, self.channel, self.width))

        ret_ndarray = np.expand_dims(ret_ndarray, axis=0)

        return ret_ndarray

    @property
    def channels_ordering(self) -> ChannelOrdering:
        """
        kp.ChannelOrdering: Channel ordering of feature map. (Options: KP_CHANNEL_ORDERING_HCW, KP_CHANNEL_ORDERING_CHW)
        """
        return self.__channels_ordering

    def get_member_variable_dict(self) -> dict:
        return {
            'width': self.width,
            'height': self.height,
            'channel': self.channel,
            'channels_ordering': str(self.channels_ordering),
            'num_data': self.num_data,
            'ndarray': self.ndarray
        }


class InferenceFixedNodeOutput(ValueBase, ValueRepresentBase):
    """
    Generic inference node output in fixed-point format.

    Attributes
    ----------
    width : int, default=0
        Width of output node.
    height : int, default=0
        Height of output node.
    channel : int, default=0
        Channel of output node.
    radix : int, default=0
        Radix for fixed/floating point conversion.
    scale : float, default=0
        Scale for fixed/floating point conversion.
    factor : float, default=0
        Conversion factor for fixed-point to floating-point conversion - formula: 1 / (scale * (2 ^ radix)).
    num_data : int, default=0
        Total number of fixed-point values.
    data : np.ndarray, default=np.array([])
            N-dimensional numpy.ndarray of feature map. (Channel ordering: KL520 - H,C,W; KL720 - C,H,W)
    channels_ordering : kp.ChannelOrdering, default=kp.ChannelOrdering.KP_CHANNEL_ORDERING_CHW
            Specify channel ordering of feature map. (Options: KP_CHANNEL_ORDERING_HCW, KP_CHANNEL_ORDERING_CHW)
    """

    def __init__(self,
                 width: int = 0,
                 height: int = 0,
                 channel: int = 0,
                 radix: int = 0,
                 scale: float = 0,
                 factor: float = 0,
                 num_data: int = 0,
                 data: np.ndarray = np.array([]),
                 channels_ordering: ChannelOrdering = ChannelOrdering.KP_CHANNEL_ORDERING_CHW):
        """
        Generic inference node output in fixed-point format.

        Parameters
        ----------
        width : int, default=0
            Width of output node.
        height : int, default=0
            Height of output node.
        channel : int, default=0
            Channel of output node.
        radix : int, default=0
            Radix for fixed/floating point conversion.
        scale : float, default=0
            Scale for fixed/floating point conversion.
        factor : float, default=0
            Conversion factor for fixed-point to floating-point conversion - formula: 1 / (scale * (2 ^ radix)).
        num_data : int, default=0
            Total number of fixed-point values.
        data : np.ndarray, default=np.array([])
            N-dimensional numpy.ndarray of feature map. (Channel ordering: KL520 - H,C,W; KL720 - C,H,W)
        channels_ordering : kp.ChannelOrdering, default=kp.ChannelOrdering.KP_CHANNEL_ORDERING_CHW
            Specify channel ordering of feature map. (Options: KP_CHANNEL_ORDERING_HCW, KP_CHANNEL_ORDERING_CHW)
        """
        ValueBase.__init__(self,
                           element_buffer_class=InfFixedNodeOutputBuffer,
                           width=width,
                           height=height,
                           channel=channel,
                           radix=radix,
                           scale=scale,
                           factor=factor,
                           num_data=num_data,
                           data=data)

        self.__channels_ordering = channels_ordering

    def __del__(self):
        if self._is_allocate_from_c:
            wrapper_utils.c_free(pointer=self._element_buffer.contents)
            self._is_allocate_from_c = False

    def _cast_element_buffer(self) -> None:
        self._element_buffer = ctypes.pointer(self._element_buffer)

    def _get_element_buffer(self) -> Union[None, ctypes.POINTER]:
        return self._element_buffer

    @property
    def width(self) -> int:
        """
        int: Width of output node.
        """
        return self._element_buffer.contents._width

    @property
    def height(self) -> int:
        """
        int: Height of output node.
        """
        return self._element_buffer.contents._height

    @property
    def channel(self) -> int:
        """
        int: Channel of output node.
        """
        return self._element_buffer.contents._channel

    @property
    def radix(self) -> int:
        """
        int: Radix for fixed/floating point conversion.
        """
        return self._element_buffer.contents._radix

    @property
    def scale(self) -> float:
        """
        float: Scale for fixed/floating point conversion.
        """
        return self._element_buffer.contents._scale

    @property
    def factor(self) -> float:
        """
        float: Conversion factor for fixed-point to floating-point conversion - formulation: 1 / (scale * (2 ^ radix)).
        """
        return self._element_buffer.contents._factor

    @property
    def num_data(self) -> int:
        """
        int: Total number of fixed-point values.
        """
        return self._element_buffer.contents._num_data

    @property
    def ndarray(self) -> np.ndarray:
        """
        numpy.ndarray: N-dimensional numpy.ndarray of feature map.
        """
        if self._is_allocate_from_c:
            address = ctypes.addressof(self._element_buffer.contents._data)
            buffer_as_ctypes_array = (ctypes.c_int8 * self._element_buffer.contents._num_data).from_address(address)
        else:
            buffer_as_ctypes_array = self._element_buffer.contents._data[:self._element_buffer.contents._num_data]

        ret_ndarray = np.ctypeslib.as_array(buffer_as_ctypes_array)

        if self.channels_ordering == ChannelOrdering.KP_CHANNEL_ORDERING_CHW:
            ret_ndarray = ret_ndarray.reshape((self.channel, self.height, self.width))
        elif self.channels_ordering == ChannelOrdering.KP_CHANNEL_ORDERING_HCW:
            ret_ndarray = ret_ndarray.reshape((self.height, self.channel, self.width))

        ret_ndarray = np.expand_dims(ret_ndarray, axis=0)

        return ret_ndarray

    @property
    def channels_ordering(self) -> ChannelOrdering:
        """
        kp.ChannelOrdering: Channel ordering of feature map. (Options: KP_CHANNEL_ORDERING_HCW, KP_CHANNEL_ORDERING_CHW)
        """
        return self.__channels_ordering

    def get_member_variable_dict(self) -> dict:
        return {
            'width': self.width,
            'height': self.height,
            'channel': self.channel,
            'radix': self.radix,
            'scale': self.scale,
            'factor': self.factor,
            'channels_ordering': str(self.channels_ordering),
            'num_data': self.num_data,
            'ndarray': self.ndarray
        }

    def to_float_node_output(self) -> InferenceFloatNodeOutput:
        """
        Convert fixed-point node output to floating-point node output.

        Returns
        -------
        inference_float_node_output : kp.InferenceFloatNodeOutput
        """
        return InferenceFloatNodeOutput(
            width=self.width,
            height=self.height,
            channel=self.channel,
            num_data=self.num_data,
            data=(self.ndarray * self.factor).astype(np.float32),
            channels_ordering=self.channels_ordering
        )


class BoundingBox(ValueBase, ValueRepresentBase):
    """
    Bounding box descriptor.

    Attributes
    ----------
    x1 : float, default=0
        X coordinate of bounding box top-left corner.
    y1 : float, default=0
        Y coordinate of bounding box top-left corner.
    x2 : float, default=0
        X coordinate of bounding box bottom-right corner.
    y2 : float, default=0
        Y coordinate of bounding box bottom-right corner.
    score : float, default=0
        Probability score.
    class_num : int, default=0
        Class # (of many) with highest probability.
    """

    def __init__(self,
                 x1: float = 0,
                 y1: float = 0,
                 x2: float = 0,
                 y2: float = 0,
                 score: float = 0,
                 class_num: int = 0):
        """
        Bounding box descriptor.

        Parameters
        ----------
        x1 : float, default=0
            X coordinate of bounding box top-left corner.
        y1 : float, default=0
            Y coordinate of bounding box top-left corner.
        x2 : float, default=0
            X coordinate of bounding box bottom-right corner.
        y2 : float, default=0
            Y coordinate of bounding box bottom-right corner.
        score : float, default=0
            Probability score.
        class_num : int, default=0
            Class # (of many) with highest probability.
        """
        ValueBase.__init__(self,
                           element_buffer_class=BoundingBoxBuffer,
                           x1=x1,
                           y1=y1,
                           x2=x2,
                           y2=y2,
                           score=score,
                           class_num=class_num)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def x1(self) -> float:
        """
        float: X coordinate of bounding box top-left corner.
        """
        return self._element_buffer._x1

    @x1.setter
    def x1(self, value: float):
        self._element_buffer._x1 = value

    @property
    def y1(self) -> float:
        """
        float: Y coordinate of bounding box top-left corner.
        """
        return self._element_buffer._y1

    @y1.setter
    def y1(self, value: float):
        self._element_buffer._y1 = value

    @property
    def x2(self) -> float:
        """
        float: X coordinate of bounding box bottom-right corner.
        """
        return self._element_buffer._x2

    @x2.setter
    def x2(self, value: float):
        self._element_buffer._x2 = value

    @property
    def y2(self) -> float:
        """
        float: Y coordinate of bounding box bottom-right corner.
        """
        return self._element_buffer._y2

    @y2.setter
    def y2(self, value: float):
        self._element_buffer._y2 = value

    @property
    def score(self) -> float:
        """
        float: Probability score.
        """
        return self._element_buffer._score

    @score.setter
    def score(self, value: float):
        self._element_buffer._score = value

    @property
    def class_num(self) -> int:
        """
        int: Class # (of many) with highest probability.
        """
        return self._element_buffer._class_num

    @class_num.setter
    def class_num(self, value: int):
        self._element_buffer._class_num = value

    def get_member_variable_dict(self) -> dict:
        return {
            'x1': self.x1,
            'y1': self.y1,
            'x2': self.x2,
            'y2': self.y2,
            'score': self.score,
            'class_num': self.class_num
        }


class Point(ValueBase, ValueRepresentBase):
    """
    Point descriptor.

    Attributes
    ----------
    x : int, default=0
        X coordinate of point.
    y : int, default=0
        Y coordinate of point.
    """

    def __init__(self,
                 x: int = 0,
                 y: int = 0):
        """
        Point descriptor.

        Parameters
        ----------
        x : int, default=0
            X coordinate of point.
        y : int, default=0
            Y coordinate of point.
        """
        ValueBase.__init__(self,
                           element_buffer_class=PointBuffer,
                           x=x,
                           y=y)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def x(self) -> float:
        """
        int: X coordinate of point.
        """
        return self._element_buffer._x

    @x.setter
    def x(self, value: float):
        self._element_buffer._x = value

    @property
    def y(self) -> float:
        """
        int: Y coordinate of point.
        """
        return self._element_buffer._y

    @y.setter
    def y(self, value: float):
        self._element_buffer._y = value

    def get_member_variable_dict(self) -> dict:
        return {
            'x': self.x,
            'y': self.y,
        }


class LandMark(ValueBase, ValueRepresentBase):
    """
    Landmark descriptor.

    Attributes
    ----------
    point_list : List[kp.Point], default=[]
        Landmark points.
    score : float, default=0
        Score of landmark.
    blur : float, default=0
        Blur score of landmark.
    class_num : int, default=0
        Class of landmark.
    """

    def __init__(self,
                 point_list: List[Point] = [],
                 score: float = 0,
                 blur: float = 0,
                 class_num: int = 0):
        """
        Landmark descriptor.

        Parameters
        ----------
        point_list : List[kp.Point], default=[]
            Landmark points.
        score : float, default=0
            Score of landmark.
        blur : float, default=0
            Blur score of landmark.
        class_num : int, default=0
            Class of landmark.
        """
        ValueBase.__init__(self,
                           element_buffer_class=LandMarkBuffer,
                           point_list=[PointBuffer(x=point.x,
                                                   y=point.y) for point in point_list],
                           score=score,
                           blur=blur,
                           class_num=class_num)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def point_list(self) -> List[Point]:
        """
        List[kp.Point]: Landmark points.
        """
        return [Point(x=point._x,
                      y=point._y) for point in self._element_buffer._marks]

    @point_list.setter
    def point_list(self, value: List[Point] = []):
        assert len(value) == Const.LAND_MARK_POINTS.value

        self._element_buffer._marks = (PointBuffer * Const.LAND_MARK_POINTS.value)(*[
            PointBuffer(x=point.x,
                        y=point.y) for point in value])

    @property
    def score(self) -> float:
        """
        int: Score of landmark.
        """
        return self._element_buffer._score

    @score.setter
    def score(self, value: float):
        self._element_buffer._score = value

    @property
    def blur(self) -> float:
        """
        int: Blur score of landmark.
        """
        return self._element_buffer._blur

    @blur.setter
    def blur(self, value: float):
        self._element_buffer._blur = value

    @property
    def class_num(self) -> int:
        """
        int: Class of landmark.
        """
        return self._element_buffer._class_num

    @class_num.setter
    def class_num(self, value: float):
        self._element_buffer._class_num = value

    def get_member_variable_dict(self) -> dict:
        member_variable_dict = {
            'score': self.score,
            'blur': self.blur,
            'class_num': self.class_num,
            'point_list': {}
        }

        for idx, point_element in enumerate(self.point_list):
            member_variable_dict['point_list'][idx] = point_element.get_member_variable_dict()

        return member_variable_dict


class Classification(ValueBase, ValueRepresentBase):
    """
    Classification result descriptor.

    Attributes
    ----------
    class_num : int, default=0
        Class # (of many) with highest probability.
    score : float, default=0
        Probability of the class.
    """

    def __init__(self,
                 class_num: int = 0,
                 score: float = 0):
        """
        Classification result descriptor.

        Attributes
        ----------
        class_num : int, default=0
            Class # (of many) with highest probability.
        score : float, default=0
            Probability of the class.
        """
        ValueBase.__init__(self,
                           element_buffer_class=ClassificationBuffer,
                           class_num=class_num,
                           score=score)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def class_num(self) -> int:
        """
        int: Class # (of many) with highest probability.
        """
        return self._element_buffer._class_num

    @class_num.setter
    def class_num(self, value: int = 0):
        self._element_buffer._class_num = value

    @property
    def score(self) -> float:
        """
        int: Probability of the class.
        """
        return self._element_buffer._score

    @score.setter
    def score(self, value: float):
        self._element_buffer._score = value

    def get_member_variable_dict(self) -> dict:
        member_variable_dict = {
            'class_num': self.class_num,
            'score': self.score
        }

        return member_variable_dict


class FaceRecognize(ValueBase, ValueRepresentBase):
    """
    Describe feature map of one face.

    Attributes
    ----------
    feature_map : numpy.ndarray, default=np.zeros((Const.FR_FEAT_LENGTH.value,), dtype=numpy.float32)
        Floating-point feature map of one face.
    feature_map_fixed : numpy.ndarray, default=np.zeros((Const.FR_FEAT_LENGTH.value,), dtype=numpy.int8)
        Fixed-point feature map of one face.
    """

    def __init__(self,
                 feature_map: np.ndarray = np.zeros((Const.FR_FEAT_LENGTH.value,), dtype=np.float32),
                 feature_map_fixed: np.ndarray = np.zeros((Const.FR_FEAT_LENGTH.value,), dtype=np.int8)):
        """
        Describe feature map of one face.

        Parameters
        ----------
        feature_map : numpy.ndarray, default=np.zeros((Const.FR_FEAT_LENGTH.value,), dtype=numpy.float32)
            Floating-point feature map of one face.
        feature_map_fixed : numpy.ndarray, default=np.zeros((Const.FR_FEAT_LENGTH.value,), dtype=numpy.int8)
            Fixed-point feature map of one face.
        """
        ValueBase.__init__(self,
                           element_buffer_class=FaceRecognizeBuffer,
                           feature_map=feature_map,
                           feature_map_fixed=feature_map_fixed)

    def _cast_element_buffer(self) -> None:
        pass

    @property
    def feature_map(self) -> np.ndarray:
        """
        numpy.ndarray: Floating-point feature map of one face.
        """
        return np.ctypeslib.as_array(self._element_buffer._feature_map)

    @property
    def feature_map_fixed(self) -> np.ndarray:
        """
        numpy.ndarray: Fixed-point feature map of one face.
        """
        return np.ctypeslib.as_array(self._element_buffer._feature_map_fixed)

    def get_member_variable_dict(self) -> dict:
        return {
            'feature_map': self.feature_map,
            'feature_map_fixed': self.feature_map_fixed
        }
